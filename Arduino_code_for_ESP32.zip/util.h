#ifndef __UTIL__
#define __UTIL__

#include <Arduino.h>
#include <stdlib.h>
#include "ESP32_plotter.h"
#include "plotter.h"
#include "cmd_buffer.h"
#include "web_socket.h"
#include "display.h"

const char prompt[] = "\nOK";

int get_psin(int a, int r);
int get_pcos(int a, int r);
void itoaf(int32_t value, char s[], uint8_t digits, const uint8_t dec_point);
void get_serial_str(char input_buf[], int max_len);
bool parse_number(char buf[], int *number, int *pnt);
bool parse_input(char buf[], char feedback[], bool ser_input);
void check_input(void); 
bool buf_to_int(char buf[], int *n);
bool parse_lines(char buf[], char feedback[], bool ser_input);
void gen_line_cnt(char buf[]);
void generate_status(char buf[]);
bool calc_arc_details(int x_start, int y_start, int x_end, int y_end, int *r, int flag, int *xorg, int *yorg, int *a_start, int *a_end);
int calc_angle(int x1, int y1, int x2, int y2);
bool plot_rectangle(int x, int y, int width, int height, int r);

#endif
