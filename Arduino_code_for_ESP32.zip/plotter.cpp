#include "util.h"
#include "char_set.h"

static bool debug = false;

extern CmdBuffer cmd_buf;

//----------------------------------------------------------------------------------------------
Plotter::Plotter(void) {
  // initiate servo
  pen_servo.attach(PIN_SERVO);
  pen_servo.write(PEN_UP);
}

//----------------------------------------------------------------------------------------------
void Plotter::move_abs(int x, int y) {
	extern int target_x, target_y;
	extern volatile bool drive_enable;
  extern portMUX_TYPE timer_3_Mux;

  if (!drive_on) power_onoff(true);
  portENTER_CRITICAL(&timer_3_Mux);
	target_x = x;
	target_y = y;
	drive_enable = true;
  portEXIT_CRITICAL(&timer_3_Mux);
  if (!pen_is_down) {
    return_x = target_x;
    return_y = target_y;
  }
  if (debug) {
    Serial.println();
    Serial.print("X: "); Serial.print(target_x); Serial.print("   Y: "); Serial.println(target_y);
  }
}

//----------------------------------------------------------------------------------------------
void Plotter::move_rel(int x, int y) {
	extern int target_x, target_y;
	extern volatile int pos_x, pos_y;
	extern volatile bool drive_enable;
  extern portMUX_TYPE timer_3_Mux;

  if (!drive_on) power_onoff(true);
  portENTER_CRITICAL(&timer_3_Mux);
	target_x += x;
	target_y += y;
	drive_enable = true;
  portEXIT_CRITICAL(&timer_3_Mux);
    if (!pen_is_down) {
    return_x = target_x;
    return_y = target_y;
  }
  if (debug) {
    Serial.println();
    Serial.print("X: "); Serial.print(target_x); Serial.print("   Y: "); Serial.println(target_y);
  }
}

//----------------------------------------------------------------------------------------------
void Plotter::close_poly(void) {
  extern int target_x, target_y;
  extern volatile bool drive_enable;
  extern portMUX_TYPE timer_3_Mux;
  
  if ((return_x > PLOT_LIMIT) && (return_y > PLOT_LIMIT)) {
    target_x = return_x;
    target_y = return_y;
    set_pen(true);
    if (!drive_on) power_onoff(true);
    portENTER_CRITICAL(&timer_3_Mux);
    drive_enable = true;
    portEXIT_CRITICAL(&timer_3_Mux);
  }
  if (debug) {
    Serial.println();
    Serial.print("X: "); Serial.print(target_x); Serial.print("   Y: "); Serial.println(target_y);
  }
}

//----------------------------------------------------------------------------------------------
void Plotter::set_pen(bool pen) {
  if (pen != pen_is_down) {
    servo_start_time = esp_timer_get_time();
    servo_wait = true;
		if (pen == false) { 
			pen_servo.write(PEN_UP);
      servo_end_time = servo_start_time + 1000 * PEN_UP_TIME;
		} else  {
			pen_servo.write(PEN_DOWN);
      servo_end_time = servo_start_time + 1000 * PEN_DOWN_TIME;
		}
    pen_is_down = pen;
  }
}

//----------------------------------------------------------------------------------------------
bool Plotter::get_pen(void) {
  return pen_is_down;
}

//----------------------------------------------------------------------------------------------
// Plots a single character as defined by uint8_t char_code.
// Sets bool char_plot_ongoing to busy until the character is completed.
void Plotter::plot_char(void) {
  static uint8_t x_len;
  static int8_t *x_pnt;
  static int draw_char_step = 0;
  static int cmd, x, y, i;
  int x_plot, y_plot;

  switch (draw_char_step) {
    case 0:                         // step: preparation
      if (char_plot_finished) {
        return;                     // nothing to do
      }
      if ((char_code < ' ') || (char_code > '~')) {
        char_plot_finished = true;
        return;                     // code is outside accepted range
      };
      x_pnt = char_set + char_pos[char_code - ' '];
      x_len = char_movement_cnt[char_code - ' '];
      i = 0;
      draw_char_step = 1;
      break;
    case 1:                         // step: get command details and set pen
      if (i >= x_len) {             // check whether the end is reached
        draw_char_step = 3;
      } else {
        cmd = *x_pnt; ++x_pnt;      // get command details and set pen
        x = *x_pnt; ++x_pnt;
        y = *x_pnt; ++x_pnt;
        i += 3;
        if (cmd == 0) set_pen(false);
        else set_pen(true);
        draw_char_step = 2;
      }
      break;
    case 2:                         // step: move
      switch (char_dir) {
        case 0:
          x_plot = x;
          y_plot = y;
          break;
        case 1:
          x_plot = y;
          y_plot = -x;
          break;
        case 2:
          x_plot = -x;
          y_plot = -y;
          break;
        case 3:
          x_plot = -y; 
          y_plot = x;
          break;
      }
      move_rel(x_plot * char_size, y_plot * char_size);
      draw_char_step = 1;
      break;
    case 3:                           // step: finish
      char_plot_finished = true;
      draw_char_step = 0;
      break;
  }  
}

//-------------------------------------------------------------------------------------------------------------
// Calculates the length of the string as captured in str_code[]
uint32_t Plotter::calc_str_len(char my_str[]) {
  uint32_t x_len = 0;
  int pnt = 0;
  char c;

  c = my_str[pnt];
  while ((c >= ' ') && (c < 127)) {
    x_len += char_xlen[c - ' '];
    ++pnt;
    c = my_str[pnt];
  };
  return x_len * char_size - char_size;;
}

//-------------------------------------------------------------------------------------------------------------
void Plotter::initiate_str_plot(char cmd) {
  int str_len;
  
  if (!string_plot_ongoing) {               // initiation does only make sense if it is not ongoing already
    string_plot_ongoing = true;             // activate string plot mode
    str_pnt = 0;                            // reset string pointer
    char_code = str_code[str_pnt];          // get first character
    char_plot_finished = false;             // first char is not finished
    if (cmd == CMD_TEXT) {                  // plot left adjusted string, start immediately
      return;
    };
    str_len = calc_str_len(str_code);       // calculate string length
    if (cmd == CMD_TEXT_CENTERED) str_len = str_len / 2;
    switch (char_dir) {                     // move to start position of the string
      case 0:                               // -> right
        move_rel(-str_len, 0);
        break;
      case 1:
        move_rel(0, -str_len);               // -> down
        break;
      case 2:
        move_rel(str_len, 0);               // -> left
        break;
      case 3:                               // -> up
        move_rel(0, str_len);      
        break;
    }
  }
}

//-------------------------------------------------------------------------------------------------------------
void Plotter::plot_str(void) {
  plot_char();                          // plot the current character
  if (char_plot_finished) {             // in case the current character is completed
    char_code = str_code[++str_pnt];    // get next character
    if (char_code >= ' ') {             // still work to be done?
      char_plot_finished = false;       // process next character
    } else {                            // otherwise we are done
      string_plot_ongoing = false;
    }
  }
}

//--------------------------------------------------------------------------------------------------------------
void Plotter::set_str_orientation(uint8_t dir) {
  char_dir = dir;
}

//--------------------------------------------------------------------------------------------------------------
void Plotter::set_str_size(uint16_t size) {
  if (size < 500) char_size = size;
}

//--------------------------------------------------------------------------------------------------------------
void Plotter::initiate_circle(void) {
  extern int target_x, target_y;
  circle_step = 2000 / (circle_r_x + circle_r_y);            // 1 degree steps for circles above 1000 radius, bigger steps for smaller circles
  if (circle_step < 1) circle_step = 1;
  if (circle_step > 25) circle_step = 25;
  while (circle_a_end < circle_a) circle_a_end += 360;

  circle_x = target_x;
  circle_y = target_y;

  if (debug) {
    Serial.println(circle_x);
    Serial.println(circle_y);
    Serial.println(circle_r_x);
    Serial.println(circle_r_y);
    Serial.println(circle_a);
    Serial.println(circle_a_end);
  }
  
  circle_plot_ongoing = true;
  set_pen(false);
  move_abs(circle_x + get_psin(circle_a, circle_r_x),
           circle_y + get_pcos(circle_a, circle_r_y));
}

//--------------------------------------------------------------------------------------------------------------
void Plotter::plot_circle(void) {
  static int circle_mode = 0;

  switch (circle_mode) {
    case 0:                         // initiate, set pen down
      circle_plot_ongoing = true;
      set_pen(true);
      circle_mode = 1;
      break;
    case 1:                         // move to next position, check whether target is reached
      circle_a += circle_step;
      if (circle_a > circle_a_end) circle_a = circle_a_end;
      move_abs(circle_x + get_psin(circle_a, circle_r_x),
               circle_y + get_pcos(circle_a, circle_r_y));
      if (circle_a >= circle_a_end) circle_mode = 2;
      break;
    case 2:                         // target reached, lift pen up
      set_pen(false);
      circle_mode = 3;
      break;
    case 3:                         // move to center of the circle
      move_abs(circle_x, circle_y);
      circle_mode = 4;
    case 4:                         // finish circle, reset data
      circle_plot_ongoing = false;
      circle_mode = 0;
      break;
  }
}

//--------------------------------------------------------------------------------------------------------------
void Plotter::initiate_arc(void) {
  extern int target_x, target_y;
  
  circle_step = 2000 / (circle_r_x + circle_r_y);            // 1 degree steps for circles above 1000 radius, bigger steps for smaller circles
  if (circle_step < 1) circle_step = 1;
  if (circle_step > 25) circle_step = 25;
  if (circle_a_end < circle_a) circle_step = -circle_step;    // manage direction

  if (debug) {
    Serial.println("initiate_arc()");
    Serial.print("circle_x: "); Serial.println(circle_x); 
    Serial.print("circle_y: "); Serial.println(circle_y); 
    Serial.print("circle_r_x: "); Serial.println(circle_r_x); 
    Serial.print("circle_r_y: "); Serial.println(circle_r_y); 
    Serial.print("circle_a: "); Serial.println(circle_a); 
    Serial.print("circle_a_end: "); Serial.println(circle_a_end); 
    Serial.print("circle_new_x: "); Serial.println(circle_new_x); 
    Serial.print("circle_new_y: "); Serial.println(circle_new_y); 
    Serial.print("circle_step: "); Serial.println(circle_step); 
  }

  set_pen(true);                // initiate: pen down
  arc_plot_ongoing = true;
}

//--------------------------------------------------------------------------------------------------------------
void Plotter::plot_arc(void) {
  static int arc_mode = 0;

  switch (arc_mode) {
    case 0:                         // move to next arc position 
      move_abs(circle_x + get_psin(circle_a, circle_r_x),
               circle_y + get_pcos(circle_a, circle_r_y));
      circle_a += circle_step;
      if (((circle_step < 0) && (circle_a < circle_a_end)) ||
          ((circle_step > 0) && (circle_a > circle_a_end))) {
            arc_mode = 1;
          }
      break;
    case 1:                         // we've reached the end
      move_abs(circle_new_x, circle_new_y);
      arc_mode = 2;
      break;
   case 2:                          // cleanup
      arc_plot_ongoing = false;
      arc_mode = 0;
      break;
  }
}


//--------------------------------------------------------------------------------------------------------------
void Plotter::plot_buffer(void) {
  extern volatile bool drive_enable;
  extern volatile int target_x, target_y;
  extern int system_state;
  extern int line_cnt;
  
  char cmd;
  uint8_t c;
  int x, y, pnt;
  char str_buf[64];

  // if drive is busy, ignore
  if (drive_enable) 
    return;

  // in case we need to wait for the servo, just exit the function
  if (servo_wait) {
    if (esp_timer_get_time() > servo_end_time) {
      servo_wait = false;
    } else {
      return;
    }
  }

  // in case a string plot is ongoing, continue working on it
  if (string_plot_ongoing) {
    plot_str();
    return;
  }

  // in case a circle plot is ongoing, continue working on it
  if (circle_plot_ongoing) {
    plot_circle();
    return;
  }

  // in case an arc plot is ongoing, continue working on it
  if (arc_plot_ongoing) {
    plot_arc();
    return;
  }

  // in case "close poly" has finished, move pen up
  if (close_poly_ongoing) {
    set_pen(false);
    close_poly_ongoing = false;
  }

  // in case the comamnd buffer is empty, return
  if (cmd_buf.get_buffer_cnt() == 0) {
    if (drive_on) {
      if (!drive_enable) system_state = SYS_STATE_READY;
    } else {
      system_state = SYS_STATE_STANDBY;
    }
    return;
  }

  // in all other cases: process next item from buffer
  system_state = SYS_STATE_PLOTTING;
  cmd = cmd_buf.get_byte();
  switch (cmd) {

    case CMD_MOVE_ABS:                        // move absolute
      x = cmd_buf.get_word();
      y = cmd_buf.get_word();
      move_abs(x, y);
      break;
      
    case CMD_MOVE_REL:                        // move relative
      x = cmd_buf.get_word();
      y = cmd_buf.get_word();
      move_rel(x, y);
      break;
            
    case CMD_CLOSE_POLY:
      close_poly_ongoing = true;
      close_poly();
      break;

    case CMD_ARC_ABS:
      circle_x = cmd_buf.get_word();
      circle_y = cmd_buf.get_word();
      circle_r_x = cmd_buf.get_word();
      circle_r_y = circle_r_x;
      circle_a = cmd_buf.get_word();
      circle_a_end = cmd_buf.get_word();
      circle_new_x = cmd_buf.get_word();
      circle_new_y = cmd_buf.get_word();
      initiate_arc();

      break;

    case CMD_CIRCLE:               // plot circle
      circle_r_x = cmd_buf.get_word();       // get radius
      circle_r_y = cmd_buf.get_word();
      circle_a = cmd_buf.get_word();         // get start angle
      while (circle_a < 0) circle_a += 360;
      circle_a_end = cmd_buf.get_word();     // get end angle
      while (circle_a_end < 0) circle_a_end += 360;
      initiate_circle();
      break;
      
    case CMD_PEN_UP:                      // pen up
      set_pen(false);
      break;  
      
    case CMD_PEN_DOWN:                    // pen down
      set_pen(true);
      break;
      
    case CMD_PAUSE:                       // powering on or off
      power_onoff(!drive_on);
      break;

    case CMD_TEXT:                        // p1ot text
    case CMD_TEXT_CENTERED:
    case CMD_TEXT_RIGHT:
      pnt = 0;
      while ((c = cmd_buf.get_byte()) > 0) {
        if (pnt < INPUT_BUFFER_SIZE - 1) {
          str_code[pnt] = c;
          ++pnt;
        }
      }
      str_code[pnt] = 0;
      initiate_str_plot(cmd);
      break;

    case CMD_TEXT_SIZE:                 // text size, 16 bit argument
      x = cmd_buf.get_word();
      set_str_size(x);
      break;

    case CMD_TEXT_ORIENTATION:                 // text orientation, 8 bit argument
      set_str_orientation(cmd_buf.get_byte());
      break;   

/*      
    case CMD_SET_LINE_CNT:
      line_cnt = cmd_buf.get_word();
      break;
    case CMD_SET_SPEED:
      extern int timer_delay_baseline_slow;
      timer_delay_baseline_slow = cmd_buf.get_word();
      if (debug) { Serial.print("Setting speed: "); Serial.println(timer_delay_baseline_slow); }
      break;
      */
      
    default:
      break;
  }
}

// reset --------------------------------------------------------------------------------------------------
void Plotter::drive_reset_y(void) {
  bool done = false;

  // Y axis --------------------------
  digitalWrite(PIN_Y_ENABLE, LOW);    // moving down towards button
  digitalWrite(PIN_Y_DIR, LOW);
  while (digitalRead(PIN_Y_BT) == HIGH) {
    digitalWrite(PIN_Y_STEP, HIGH);
    delay(RESET_SPEED);
    digitalWrite(PIN_Y_STEP, LOW);
    delay(RESET_SPEED);
  }
  delay(10);
  digitalWrite(PIN_Y_DIR, HIGH);       // moving up by 20 steps
  for (int i = 0; i < RESET_OFFSET; ++i) {
    digitalWrite(PIN_Y_STEP, HIGH);
    delay(RESET_SPEED);
    digitalWrite(PIN_Y_STEP, LOW);
    delay(RESET_SPEED);
  }
}

void Plotter::drive_reset_x(void) {
  bool done = false;
  
  // X axis --------------------------
  digitalWrite(PIN_X_ENABLE, LOW);
  digitalWrite(PIN_XA_DIR, LOW);
  digitalWrite(PIN_XB_DIR, HIGH);
  while (!done) {
    if (digitalRead(PIN_XA_BT) == HIGH) digitalWrite(PIN_XA_STEP, HIGH);
    if (digitalRead(PIN_XB_BT) == HIGH) digitalWrite(PIN_XB_STEP, HIGH);
    delay(RESET_SPEED);
    digitalWrite(PIN_XA_STEP, LOW);
    digitalWrite(PIN_XB_STEP, LOW);
    delay(RESET_SPEED);
    if ((digitalRead(PIN_XA_BT) == LOW) && (digitalRead(PIN_XB_BT) == LOW))
      done = true;
  }
  delay(10);
  digitalWrite(PIN_XA_DIR, HIGH);
  digitalWrite(PIN_XB_DIR, LOW);
  for (int i = 0; i < RESET_OFFSET; ++i) {
    digitalWrite(PIN_XA_STEP, HIGH);
    digitalWrite(PIN_XB_STEP, HIGH);
    delay(RESET_SPEED);
    digitalWrite(PIN_XA_STEP, LOW);
    digitalWrite(PIN_XB_STEP, LOW);
    delay(RESET_SPEED);  
  }  
}

// power_onoff --------------------------------------------------------------------------------------------
void Plotter::power_onoff(bool onoff) {
  if (onoff) {
    digitalWrite(PIN_Y_ENABLE, LOW);    // Power motor on
    digitalWrite(PIN_X_ENABLE, LOW);    
    drive_on = true;
  } else {
    digitalWrite(PIN_Y_ENABLE, HIGH);    // Power motor on
    digitalWrite(PIN_X_ENABLE, HIGH);    
    drive_on = false;
  }
}

// get_power_on -------------------------------------------------------------------------------------------
bool Plotter::get_power_on(void) {
  return drive_on;
}

// get_char_size ------------------------------------------------------------------------------------------
int Plotter::get_char_size(void) {
  return char_size;
}

// get_char_dir ------------------------------------------------------------------------------------------
int Plotter::get_char_dir(void) {
  return char_dir;
}

// get_speed ---------------------------------------------------------------------------------------------
int Plotter::get_speed(void) {
  extern int timer_delay_baseline_slow;
  return timer_delay_baseline_slow;
}
    
