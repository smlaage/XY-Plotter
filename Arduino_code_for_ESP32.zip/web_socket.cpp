/* 
 *  web_socket.cpp
 *  
 *  SLW - 20210220
 */

#include "web_socket.h"

// static (local) variables
static WiFiMulti WiFiMulti;
static WebSocketsServer webSocket = WebSocketsServer(SOCKET_PORT);
static Preferences preferences;
static uint8_t socket_buf[SOCKET_BUFFER_SIZE];
static int socket_buf_write_pnt = 0;
static int socket_num;
static bool socket_connected = false;
static bool debug = false;


//------------------------------------------------------------------
// Reads network credentials, local_IP and gateway_IP from non-volatile memory
// Return: false -> no network credentials in non-volatile memory
//         true -> network credentials available and loaded
bool Socket::begin(void) {
  preferences.begin("ssid", false);
  String ssid = preferences.getString("ssid", "");
  if (ssid.length() > 0) {
    ssid.toCharArray(ssid_chr, sizeof(ssid_chr));
    String password = preferences.getString("password", "");
    password.toCharArray(password_chr, sizeof(password_chr));
    static_ip_flag = preferences.getBool("static_ip_flag", "");
    if (static_ip_flag) {                   
      String local_ip_str= preferences.getString("local_ip", "");
      local_ip_str.toCharArray(local_ip_chr, sizeof(local_ip_chr));
      String gateway_ip_str = preferences.getString("gateway_ip", "");
      gateway_ip_str.toCharArray(gateway_ip_chr, sizeof(gateway_ip_chr));
    }
    if (debug) show_network_details();
    return true;
  } else {
    if (debug) Serial.println("  - no network credentials in storage");
    return false;
  }
}

//------------------------------------------------------------------
bool Socket::get_net_status(void) {
  return connected;
}

//------------------------------------------------------------------
bool Socket::get_socket_status(void) {
  return socket_connected;
}

//------------------------------------------------------------------
void Socket::connect(char ssid[], char password[], 
                     char local_ip[], char gateway_ip[]) {
  strcpy(local_ip_chr, local_ip);
  strcpy(gateway_ip_chr, gateway_ip);
  strcpy(ssid_chr, ssid);
  strcpy(password_chr, password);
  static_ip_flag = true;
  connect();
}

//------------------------------------------------------------------
void Socket::connect(char ssid[], char password[]) {
  strcpy(ssid_chr, ssid);
  strcpy(password_chr, password);
  static_ip_flag = false;
  connect();
}

//------------------------------------------------------------------
void Socket::connect(void) {
  IPAddress local_ip, gateway_ip, subnet_ip;
  connected = false;
  socket_connected = false;
  
  // static IP ? 
  if (static_ip_flag) {
    local_ip.fromString(local_ip_chr);
    gateway_ip.fromString(gateway_ip_chr);
    subnet_ip.fromString("255.255.255.0");
    if (!WiFi.config(local_ip, gateway_ip, subnet_ip)) {
      Serial.println("Failed to configure static IP address");
      static_ip_flag = false;
    }
  }

  // try connection
  WiFiMulti.addAP(ssid_chr, password_chr);
  Serial.print("Connecting .");
  for (int i = 0; i < 10; ++i) {
    if (WiFiMulti.run() == WL_CONNECTED) {
      connected = true;
      break;
    } else {
      delay(500);
      Serial.print('.');
    }
  }
  Serial.println();

  // Show results. If successful: start socket server and
  // save network credentials to non-volatile memory 
  if (connected) {
    IPAddress local_ip = WiFi.localIP();
    Serial.print("Connected to ");
    Serial.println(local_ip);
    webSocket.begin();
    webSocket.onEvent(webSocketEvent);
    Serial.println("Socket server startet");
    preferences.putString("ssid", ssid_chr);
    preferences.putString("password", password_chr);
    preferences.putBool("static_ip_flag", static_ip_flag);
    if (static_ip_flag) {
      preferences.putString("local_ip", local_ip.toString());
      preferences.putString("gateway_ip", gateway_ip.toString());
    };
  } else {
    Serial.println("Connection failed");
  }
}

//------------------------------------------------------------------
// Returns the local IP as chararray
void Socket::get_local_ip(char buf[]) {
  char util_buf[10];
  
  if (connected) {
    IPAddress local_ip = WiFi.localIP();
    itoa(local_ip[0], util_buf, 10);
    strcpy(buf, util_buf);
    for (int i = 1; i < 4; ++i) {
      strcat(buf, ".");
      itoa(local_ip[i], util_buf, 10);
      strcat(buf, util_buf);
    }
  } else {
    strcpy(buf, "-.-.-.-");
  }    
}

//------------------------------------------------------------------
// Sends a text message to client
void Socket::send(char buf[]) {
  if (socket_connected)
    webSocket.sendTXT(socket_num, buf);
}

//------------------------------------------------------------------
void Socket::disconnect(void) {
  if (connected) {
    WiFi.disconnect();
    WiFi.mode(WIFI_OFF);
    connected = false;
    socket_connected = false;
    if (debug) Serial.println("Network disconnected");
  }
}

//------------------------------------------------------------------
// Returns the number of bytes in the read buffer
uint16_t Socket::available(void) {
  if (socket_buf_write_pnt == socket_buf_read_pnt) {
    return 0;
  } else {
    if (socket_buf_read_pnt > socket_buf_write_pnt) 
      return SOCKET_BUFFER_SIZE - socket_buf_read_pnt + socket_buf_write_pnt;
    else
      return socket_buf_write_pnt - socket_buf_read_pnt;
  }
}

//------------------------------------------------------------------
// Copies all currently available bytes from read buffer 
void Socket::read_chararray(char buf[], int size) {
  int i = 0;  
  while ((socket_buf_write_pnt != socket_buf_read_pnt) && (i < size - 1)) {
    buf[i] = socket_buf[socket_buf_read_pnt];
    socket_buf_read_pnt += 1;
    if (socket_buf_read_pnt >= SOCKET_BUFFER_SIZE)
      socket_buf_read_pnt = 0;
    i += 1;
  }
  buf[i] = '\0';
}

//------------------------------------------------------------------
void Socket::run_socket_loop(void) {
  if (connected)
    webSocket.loop();
}

// show_network_details --------------------------------------------
// Displays the current network setting as stored in non-volatile memory
void Socket::show_network_details(void) {
  Serial.println();
  Serial.println("Network details");
  Serial.print("  - ssid: "); Serial.println(ssid_chr);
  Serial.print("  - password: "); Serial.println(password_chr);
  Serial.print("  - static ip: ");
  if (static_ip_flag) {
    Serial.println("yes");
  } else {
    Serial.println("no");
  }
  if (static_ip_flag || connected) {                    
    Serial.print("  - local_ip: "); Serial.println(local_ip_chr);
  }
  if (static_ip_flag) {
    Serial.print("  - gateway_ip: "); Serial.println(gateway_ip_chr);
  }
  if (connected)
    Serial.print("  - ");
  else
    Serial.print("  - not ");
  Serial.println("connected");
  Serial.println();
}

/* scan ----------------------------------------------------------------------------
 * Disconnects a running network connection and
 * lists all available networks to the serial interface.
 * Returns the number of available networks
 */
uint16_t Socket::scan(void) {
  int n;

  disconnect();
  Serial.print("Network scan ... ");
  n = WiFi.scanNetworks();
  Serial.println("completed");
  if (n == 0) {
    Serial.println("No networks found"); 
  } else {
    for (int i = 0; i < n; ++i) {
      // print SSID and RSSI for each network found
      Serial.print(i+1); Serial.print(": "); Serial.print(WiFi.SSID(i));
      Serial.print(" ("); Serial.print(WiFi.RSSI(i)); Serial.print(") ");
      Serial.println((WiFi.encryptionType(i) == WIFI_AUTH_OPEN) ? " " : "*");
    }
  }
  Serial.println();
  return n;
}

/* select --------------------------------------------------------------------------
 * Scans network, prompts for connection details via a manual dialog on the serial interface.
 * The connection details are captured in non-volatile memory.
*/
void Socket::select(void) {
  String util;
  char input_buf[16];
  int network_cnt, network_select, input_buf_pnt = 0;
  bool done = false, cancelled = false;

  // clear data in memory
  Serial.println();
  ssid_chr[0] = '\0';
  password_chr[0] = '\0';
  static_ip_flag = false;
  local_ip_chr[0] = '\0';
  gateway_ip_chr[0] = '\0';

  // show available networks
  network_cnt = scan();     // disconnect and retrieve all available networks
  if (network_cnt == 0) {
    return;
  }

  // get ssid
  while (!done) {
    Serial.print(msg_select_network);
    get_serial_input(input_buf, sizeof(input_buf), true);
    network_select = atoi(input_buf);
    if (network_select > network_cnt) {
      Serial.println(msg_wrong_input);
    } else if (network_select <= 0) {
      done = true;
      cancelled = true;
    } else {
      done = true;
      WiFi.SSID(network_select - 1).toCharArray(ssid_chr, sizeof(ssid_chr));
    }
  }

  // get password
  if (!cancelled) {
    Serial.print(msg_enter_password); 
    Serial.print(ssid_chr);
    Serial.print(msg_enter_password_2);
    get_serial_input(password_chr, sizeof(password_chr), false);
    if (strlen(password_chr) < 3) {
      cancelled = true;
    } 
  }

  // check for static IP flag
  if (!cancelled) {
    Serial.print(msg_static_ip_yn);
    get_serial_input(input_buf, sizeof(input_buf), true);
    if (toupper(input_buf[0]) == 'Y') { 
      static_ip_flag = true; 
    }
  }

  if (!cancelled && static_ip_flag) {
    // get local IP
    done = false;
    while (!done) {
      Serial.print(msg_enter_local_ip);
      get_serial_input(local_ip_chr, sizeof(local_ip_chr), true);     
      done = check_ip_chr(local_ip_chr);
      if (!done) Serial.println(msg_wrong_input);
    }

    // get gateway IP
    done = false;
    while (!done) {
      Serial.print(msg_enter_gateway_ip);
      get_serial_input(gateway_ip_chr, sizeof(gateway_ip_chr), true);             
      done = check_ip_chr(gateway_ip_chr);
      if (!done) Serial.println(msg_wrong_input);
    }
  }

  if (cancelled) {
    // check whether data should be removed
    Serial.println(msg_cancelled);
    Serial.print(msg_delete_credentials_yn);
    get_serial_input(input_buf, sizeof(input_buf), true);
    if (toupper(input_buf[0]) == 'Y') {
      preferences.putString("ssid", "");
      preferences.putString("password", "");
      preferences.putBool("static_ip_flag", false);
    }    
  } else {
    connect();
  }
  
  if (debug) show_network_details();
}

//------------------------------------------------------------------
// Analyses a chararray for validity in terms of an IP address
// The chararray must include 3 dots and can only have numbers
bool Socket::check_ip_chr(char buf[]) {
  bool result = true;
  int dot_cnt = 0;
  
  for (int i = 0; i < strlen(buf); ++i) {
    if (buf[i] == '.') dot_cnt += 1;
    else if ((buf[i] < '0') || (buf[i] > '9')) 
      return false;
  }
  if (dot_cnt == 3) return true;
  else return false;
}

//------------------------------------------------------------------
// Retrieves an input line from the serial interface
// Parameter show determines whether the entered text is shown. 
void Socket::get_serial_input(char buf[], int buf_size, bool show) {
  while (!Serial.available());
  String util = Serial.readString();
  util.toCharArray(buf, buf_size);
  if (buf[strlen(buf)-1] == '\n')
    buf[strlen(buf)-1] = '\0';
  if (show) {
    Serial.println(buf);
  } else {
    for (int i = 0; i < strlen(buf); ++i)
      Serial.print('*');
    Serial.println();
  }  
}

//------------------------------------------------------------------
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  
  switch(type) {
  
    case WStype_DISCONNECTED:
      if (debug) {
        Serial.print('['); Serial.print(num); Serial.print("] ");
        Serial.println("Disconnected");
      }
      socket_connected = false;
      break;
    
    case WStype_CONNECTED: 
      if (debug) {
        IPAddress ip = webSocket.remoteIP(num);
        Serial.print('['); Serial.print(num); Serial.print("] ");
        Serial.print("Connected to ");
        Serial.print(ip[0]); Serial.print('.');
        Serial.print(ip[1]); Serial.print('.');
        Serial.print(ip[2]); Serial.print('.');
        Serial.println(ip[3]);
      }
      socket_num = num;
      socket_connected = true;
      break;
    
    case WStype_TEXT:
      for (int i = 0; i < length; ++i) {    // copy message to socket buffer
        socket_buf[socket_buf_write_pnt] = payload[i];
        socket_buf_write_pnt += 1;
        if (socket_buf_write_pnt >= SOCKET_BUFFER_SIZE) socket_buf_write_pnt = 0;
      }
      break;
            
    case WStype_BIN:
      Serial.print('['); Serial.print(num); Serial.print("] ");
      Serial.println("Unexpected message type BIN");
      break;
    
    case WStype_ERROR:      
    case WStype_FRAGMENT_TEXT_START:
    case WStype_FRAGMENT_BIN_START:
    case WStype_FRAGMENT:
    case WStype_FRAGMENT_FIN:
      Serial.print('['); Serial.print(num); Serial.print("] ");
      Serial.println("Unexpected event type");
      break;
  }
}
