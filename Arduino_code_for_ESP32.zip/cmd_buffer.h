/* cmd_buffer.h */

#ifndef __CMD_BUFFER__
#define __CMD_BUFFER__

#include <Arduino.h>
#include "ESP32_plotter.h"

#define CMD_BUFFER_SIZE 50000

class CmdBuffer {
	
	private:
		uint8_t buffer[CMD_BUFFER_SIZE];
		uint32_t buffer_wr_pnt = 0, buffer_rd_pnt = 0;
    void inc_rd_pnt(void);
    void inc_wr_pnt(void);
	
	public:
    bool buffer_full = false;
    bool echo = false;
		uint8_t get_byte(void);
		int get_word(void);
		void add_byte(uint8_t b);
		void add_word(uint16_t w);
		uint32_t get_buffer_cnt(void);
    void clear_buffer(void);
};

#endif
