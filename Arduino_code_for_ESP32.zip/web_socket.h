/*
 * web_socket.h
 * 
 * SLW 20210220
 */

#ifndef __WEB_SOCKET__
#define __WEB_SOCKET__

#include <WiFi.h>
#include <WiFiMulti.h>
#include <WiFiClientSecure.h>
#include <WebSocketsServer.h>
#include <Preferences.h>

#define SOCKET_BUFFER_SIZE 2048
#define SOCKET_PORT          90

// Text messages for network selection dialog
static const char msg_wrong_input[] = "Wrong input"; 
static const char msg_cancelled[] = "Cancelled"; 
static const char msg_no_network[] = "No network available"; 
static const char msg_select_network[] = "Select network (0 for cancel): ";
static const char msg_enter_password[] = "Enter password for '";
static const char msg_enter_password_2[] = "': ";
static const char msg_static_ip_yn[] = "Static IP? (Y/N) ";
static const char msg_enter_local_ip[] = "Enter local IP (format 192.168.1.70): ";
static const char msg_enter_gateway_ip[] = "Enter gateway IP (format 192.168.1.1): ";
static const char msg_delete_credentials_yn[] = "Delete network credentials? (Y/N) ";

// class Socket --------------------------------------------------------

class Socket {
  
  private:
    // variables
    bool connected = false;
    char ssid_chr[30], password_chr[30], local_ip_chr[30], gateway_ip_chr[30];
    bool static_ip_flag = false;
    int socket_buf_read_pnt = 0;
    // function prototypes
    void show_network_details(void);
    uint16_t scan(void);
    void get_serial_input(char buf[], int buf_size, bool show);
    bool check_ip_chr(char buf[]);
  
  public:
    bool begin(void);
    void connect(char ssid[], char password[], char local_ip_chr[], char gateway_ip_chr[]);
    void connect(char ssid[], char password[]);
    void connect(void);
    void disconnect(void);
    void select(void);
    void get_local_ip(char buf[]);
    bool get_net_status(void);
    bool get_socket_status(void);
    void run_socket_loop(void);
    uint16_t available(void);
    void read_chararray(char buf[], int size);
    void send(char buf[]);
    
};

// Function prototypes (outside the class)
//------------------------------------------------------------------
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length);

#endif
