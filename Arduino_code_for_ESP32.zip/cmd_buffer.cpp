/* cmd_buffer.cpp */

#include "cmd_buffer.h"
#include "ESP32_plotter.h"

//----------------------------------------------------------------------------------------------
void CmdBuffer::inc_rd_pnt(void) {
	if (buffer_rd_pnt >= CMD_BUFFER_SIZE -1)
		buffer_rd_pnt = 0;
	else
		++buffer_rd_pnt;
}

//----------------------------------------------------------------------------------------------
void CmdBuffer::inc_wr_pnt(void) {
	if (buffer_wr_pnt >= CMD_BUFFER_SIZE -1)
		buffer_wr_pnt = 0;
	else
		++buffer_wr_pnt;
}

//----------------------------------------------------------------------------------------------
uint8_t CmdBuffer::get_byte(void) {
	uint8_t result;

  if (get_buffer_cnt() < 1) return 0;
	result = buffer[buffer_rd_pnt];
	inc_rd_pnt();
	return result;
};

//----------------------------------------------------------------------------------------------
int CmdBuffer::get_word(void) {
	int16_t result;

  if (get_buffer_cnt() < 2) return 0;
	result = buffer[buffer_rd_pnt] << 8;		// getting high byte
	inc_rd_pnt();
	result += buffer[buffer_rd_pnt];			// getting low byte
	inc_rd_pnt();
	return result;
};

//----------------------------------------------------------------------------------------------
uint32_t CmdBuffer::get_buffer_cnt(void) {
	if (buffer_wr_pnt == buffer_rd_pnt)
		return 0;
	else {
		if (buffer_wr_pnt > buffer_rd_pnt)
			return buffer_wr_pnt - buffer_rd_pnt;
		else
			return CMD_BUFFER_SIZE - buffer_rd_pnt + buffer_wr_pnt;
	}
};

//----------------------------------------------------------------------------------------------
void CmdBuffer::add_byte(uint8_t b) {
	uint16_t result;

	buffer[buffer_wr_pnt] = b;
	inc_wr_pnt();
};

//----------------------------------------------------------------------------------------------
void CmdBuffer::add_word(uint16_t w) {
	uint16_t result;
  
	buffer[buffer_wr_pnt] = w >> 8;				// adding high byte
	inc_wr_pnt();
	buffer[buffer_wr_pnt] = w & 0xff;			// adding low byte
	inc_wr_pnt();
};

//----------------------------------------------------------------------------------------------
void CmdBuffer::clear_buffer(void) {
  buffer_rd_pnt = buffer_wr_pnt;
};
