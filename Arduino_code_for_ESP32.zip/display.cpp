#include "util.h"

LiquidCrystal_I2C lcd(I2C_ADDRESS, 20, 4);

#define DEBUG false

// -----------------------------------------------------------------------------------------
void LCD_Display::start_display(void) {
  lcd.begin(20, 4);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("PLT");
  lcd.setCursor(0, 2);
  lcd.print("Buffer:");
  lcd.setCursor(7, 3);
  lcd.print("/");
}

//------------------------------------------------------------------------------------------
void LCD_Display::show_counter(int cnt) {
  
  lcd.setCursor(18, 0);
  if (cnt < 9) lcd.print(' ');
  lcd.print(cnt);
}

//------------------------------------------------------------------------------------------
void LCD_Display::show_ip(void) {
  extern Socket ws;
  char util_buf[16];
  
  lcd.setCursor(8, 0);
  lcd.print("            ");
  ws.get_local_ip(util_buf);
  lcd.setCursor(20 - strlen(util_buf), 0);
  lcd.print(util_buf);
}

//------------------------------------------------------------------------------------------
void LCD_Display::clear_ip(void) {
  lcd.setCursor(8, 0);
  lcd.print("            ");
  lcd.setCursor(20 - 7, 0);
  lcd.print("-.-.-.-");
}

// -----------------------------------------------------------------------------------------
void LCD_Display::show_pos(int x, int y) {
  static int pos_x_old = -1, pos_y_old = -1;
  char buf[16];

  if (x != pos_x_old) {
    pos_x_old = x;
    itoaf(x, buf, 5, 0);
    lcd.setCursor(0, 3);
    lcd.print(buf);
    if (DEBUG) { Serial.print("X: "); Serial.println(buf); }
  }
  if (y != pos_y_old) {
    pos_y_old = y;
    itoaf(y, buf, 5, 0);
    lcd.setCursor(8, 3);
    lcd.print(buf);
    if (DEBUG) { Serial.print("Y: "); Serial.println(buf); }
  } 
}	

// show_system_state ---------------------------------------------------------------------------------------
void LCD_Display::show_system_state(int system_state) {
  static int system_state_old = -1;
  if (system_state != system_state_old) {
    lcd.setCursor(0, 1);
    lcd.print("        ");
    lcd.setCursor(0, 1);
    switch (system_state) {
      case 0: lcd.print("Reset Y"); break;
      case 1: lcd.print("Reset X"); break;
      case 2: lcd.print("Ready"); break;
      case 3: lcd.print("Standby"); break;
      case 4: lcd.print("Plotting"); break;
      case 5: lcd.print("Stopped"); break;
      case 6: lcd.print("Manual"); break;
      deault: lcd.print("Undefined"); break;
    }
    system_state_old = system_state;
  }
}

// show_socket_status --------------------------------------------------------------------------------------
void LCD_Display::show_socket_status(bool socket_status) {
  lcd.setCursor(4, 0);
  if (socket_status) lcd.print('*');
  else lcd.print(' ');
}

// show_buf_cnt --------------------------------------------------------------------------------------------
void LCD_Display::show_buf_cnt(int buf_cnt) {
  static int buf_cnt_old = -1;
  char str_buf[16];

  if (buf_cnt != buf_cnt_old) {
    itoaf(buf_cnt, str_buf, 5, 0);
    lcd.setCursor(7, 2);
    lcd.print(str_buf);
    if (DEBUG) { Serial.print("Buffer Cnt: "); Serial.println(str_buf); }
    buf_cnt_old = buf_cnt;
  }
}

// show_pen ------------------------------------------------------------------------------------------------
void LCD_Display::show_pen(bool pen_status) {
  static bool pen_old = true;
  
  if (pen_status != pen_old) {
    pen_old = pen_status;
    lcd.setCursor(16, 3);
    if (pen_status) { 
      lcd.print("Down");
      if (DEBUG) Serial.println("Pen: Down");
    } else {
      lcd.print("  Up");
      if (DEBUG) Serial.println("Pen: Up");
    }
  }
}		
	
