#ifndef __PLOTTER__
#define __PLOTTER__

#include <Arduino.h>
#include <ESP32Servo.h>
#include "ESP32_plotter.h"
#include "cmd_buffer.h"
#include "util.h"

class Plotter {
	
	private:
		Servo pen_servo;
    int return_x = PLOT_LIMIT, return_y = PLOT_LIMIT; 
    uint16_t char_size = 25;
    uint8_t char_dir = 0;
    uint8_t char_orientation = 0;
    uint64_t servo_start_time, servo_end_time;
    bool servo_wait = false;
    bool char_plot_finished = false;
    bool string_plot_ongoing = false;
    bool circle_plot_ongoing = false;
    bool arc_plot_ongoing = false;
    bool close_poly_ongoing = false;
    int circle_x, circle_y, circle_r_x, circle_r_y, circle_a, circle_a_end, circle_step, circle_new_x, circle_new_y;
    uint8_t char_code;        // character to be plotted
    char str_code[INPUT_BUFFER_SIZE];
    int str_pnt = 0;
    uint32_t calc_str_len(char my_str[]);
    bool drive_on = true;
    void initiate_circle(void);
    void plot_circle(void); 
    void initiate_arc(void);
    void plot_arc(void); 
    
	public:
    bool pen_is_down = false;
		Plotter(void);
		void move_abs(int x, int y);
		void move_rel(int x, int y);
    void close_poly(void);
		void set_pen(bool pen);
    bool get_pen(void);
    void plot_char(void);
    void plot_str(void);
    void initiate_str_plot(char cmd);
    void set_str_orientation(uint8_t dir);
    void set_str_size(uint16_t size);
    void plot_buffer(void);
    void drive_reset_x(void);
    void drive_reset_y(void);
    bool get_power_on(void);
    void power_onoff(bool onoff);
    int get_char_size(void);
    int get_char_dir(void);
    int get_speed(void);
};

#endif
