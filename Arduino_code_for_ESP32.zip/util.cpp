#import "util.h"

static bool debug = false;

static float psin[] = {
  0.00000, 0.01745, 0.03490, 0.05234, 0.06976, 0.08716, 0.10453, 0.12187, 0.13917, 0.15643, 
  0.17365, 0.19081, 0.20791, 0.22495, 0.24192, 0.25882, 0.27564, 0.29237, 0.30902, 0.32557, 
  0.34202, 0.35837, 0.37461, 0.39073, 0.40674, 0.42262, 0.43837, 0.45399, 0.46947, 0.48481, 
  0.50000, 0.51504, 0.52992, 0.54464, 0.55919, 0.57358, 0.58779, 0.60182, 0.61566, 0.62932, 
  0.64279, 0.65606, 0.66913, 0.68200, 0.69466, 0.70711, 0.71934, 0.73135, 0.74314, 0.75471, 
  0.76604, 0.77715, 0.78801, 0.79864, 0.80902, 0.81915, 0.82904, 0.83867, 0.84805, 0.85717, 
  0.86603, 0.87462, 0.88295, 0.89101, 0.89879, 0.90631, 0.91355, 0.92050, 0.92718, 0.93358, 
  0.93969, 0.94552, 0.95106, 0.95630, 0.96126, 0.96593, 0.97030, 0.97437, 0.97815, 0.98163, 
  0.98481, 0.98769, 0.99027, 0.99255, 0.99452, 0.99619, 0.99756, 0.99863, 0.99939, 0.99985, 
  1.00000 
};

/* ----------------------------------------------------------------------------------------
 *  Simplified sinus calculation with lookup table
 */
int get_psin(int a, int r) {
  int a_lookup;
  float x;

  while (a > 360) a -= 360;
  if (a <= 90) a_lookup = a;
  else if (a <= 180) a_lookup = 180 - a;
  else if (a <= 270) a_lookup = a - 180;
  else a_lookup = 360 - a;
  x = psin[a_lookup] * r;
  if (a > 180) x = -x;
  return ((int) x);
}

/* ----------------------------------------------------------------------------------------
 *  Simplified cosinus calculation with lookup table
 */
int get_pcos(int a, int r) {
  int a_lookup;
  float x;

  a += 90;
  return get_psin(a, r);
}


/* ------------------------------------------------------------------------------------------
 *  Scans a string for a decimal number. Accepted characters include 0 ... 9, -, +.
 *  Acceptable termination characters are ' ', ',', ';', '\0', '\n'.
 *  Any other characters cause an error.
 *  Leading comma will be skipped.
 *  Parameters: 
 *    char buf[] -> char array that includes the string to be scanned
 *    int *n -> integer resulting from the scan
 *    int *pnt -> position in the string following the last character of the number, blanks are being skipped
 */

bool parse_number(char buf[], int *number, int *pnt) {
  bool minus_flag = false;
  char c;
  bool scan_end =false, okay = false;

  if (buf[*pnt] == ',') ++*pnt;
  
  while ((buf[*pnt] == ' ') || (buf[*pnt] == '\t') || (buf[*pnt] == ',')) ++*pnt;

  *number = 0;
  while (!scan_end) {
    c = buf[*pnt];  
    if ((c == '-') && (!minus_flag)) {
      minus_flag = true;
      ++*pnt;
    } else if ((c >= '0') && (c <= '9')) {
      *number = 10 * *number + (c - '0');
      ++*pnt;
      okay = true;
    } else if (c == '+') {
      ++*pnt;
    } else if ((c == ' ') || (c == ',') || (c == ';') || (c == '\n') || (c == '\0')) {
      scan_end = true;
    } else {
      scan_end = true;
      okay = false;
    }
  }
  if (minus_flag) *number = -*number;
  while (buf[*pnt] == ' ') ++*pnt;           // skip trailing blanks
  return okay;
}

/* ------------------------------------------------------------------------------------------
 *  Scans an input line for and takes action according to the content of the line.
 *  Parameters:
 *    char buf[] -> input line
 *    char feedback[] -> resulting data. In case of error it contains a '?'.
 *    return value: true for "feedback is available", false for "no feedback"
 */
bool parse_input(char buf[], char feedback[], bool ser_input) {
  bool error_flag = false, feedback_flag = false;
  char cmd;
  char util_buf[16];
  int x, y, r_x, r_y, xorg, yorg, a_start, a_end, flag, h;
  int pnt = 0, len;
  extern Plotter pl;
  extern Socket ws;
  extern CmdBuffer cmd_buf;
  extern LCD_Display disp;
  extern int target_x, target_y;
 
  // check for sufficient memory
  if (strlen(buf) > CMD_BUFFER_SIZE - cmd_buf.get_buffer_cnt()) {
    strcpy(feedback, "X"); 
    return true;
  }

  // reset feedback
  feedback[0] = '\0';

  // process input
  cmd = buf[pnt];
  switch (cmd) {

    case CMD_MOVE_ABS:                            // 1 - move absolute
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {          // get x
        if (buf[pnt] == ',') {                    // comma expected
          ++pnt;
          if (parse_number(buf, &y, &pnt)) {      // get y
            cmd_buf.add_byte(CMD_PEN_UP);
            cmd_buf.add_byte(CMD_MOVE_ABS);
            cmd_buf.add_word(x);
            cmd_buf.add_word(y);
          } else error_flag = true;
        } else error_flag = true;
      } else error_flag = true;
      break;

    case CMD_MOVE_REL:                            // 2 - move relative
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {          // get x
        if (buf[pnt] == ',') {                    // comma expected
          ++pnt;
          if (parse_number(buf, &y, &pnt)) {      // get y
            cmd_buf.add_byte(CMD_PEN_UP);
            cmd_buf.add_byte(CMD_MOVE_REL);
            cmd_buf.add_word(x);
            cmd_buf.add_word(y);
          } else error_flag = true;
        } else error_flag = true;
      } else error_flag = true;
      break;
    
    case CMD_LINE_ABS:                            // 3 - line absolute
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {          // get x
        if (buf[pnt] == ',') {                    // comma expected
          ++pnt;
          if (parse_number(buf, &y, &pnt)) {      // get y
            cmd_buf.add_byte(CMD_PEN_DOWN);
            cmd_buf.add_byte(CMD_MOVE_ABS);
            cmd_buf.add_word(x);
            cmd_buf.add_word(y);
          } else error_flag = true;
        } else error_flag = true;
      } else error_flag = true;
      break;

    case CMD_LINE_REL:                            // 4 - line relative
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {          // get x
        if (buf[pnt] == ',') {                    // comma expected
          ++pnt;
          if (parse_number(buf, &y, &pnt)) {      // get y
            cmd_buf.add_byte(CMD_PEN_DOWN);
            cmd_buf.add_byte(CMD_MOVE_REL);
            cmd_buf.add_word(x);
            cmd_buf.add_word(y);
          } else error_flag = true;
        } else error_flag = true;
      } else error_flag = true;
      break;

    case CMD_RECTANGLE_ABS:                         // rectangle absolute
    case CMD_RECTANGLE_REL:
      h = 0;
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {            // x
        if (parse_number(buf, &y, &pnt)) {          // y
          if (parse_number(buf, &r_x, &pnt) && (r_x > 0)) {     // width
            if (parse_number(buf, &r_y, &pnt) && (r_y > 0)) {   // height
              if ((buf[pnt] != ';') && (buf[pnt] != '\n') && (buf[pnt] != '\0')) {       // more to come?
                if (parse_number(buf, &h, &pnt) && (h > 0)) {   // radius
                  ;
                } else error_flag = true;
              }
            } else error_flag = true;
          } else error_flag = true;
        } else error_flag = true;
      } else error_flag = true;
      if (!error_flag) {
        if (cmd == CMD_RECTANGLE_ABS) {
          if (!plot_rectangle(x, y, r_x, r_y, h)) {
            error_flag = true;
          }
        }
        else if (!plot_rectangle(target_x + x, target_y + y, r_x, r_y, h)) {
          error_flag = true;
        }
      }
      break;

    case CMD_ARC_ABS:                               // 9 - arc absolute
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {                        // x
        if (parse_number(buf, &y, &pnt)) {                      // y
          if (parse_number(buf, &r_x, &pnt) && (r_x > 0)) {     // r
            if (parse_number(buf, &flag, &pnt)) {
              if (calc_arc_details(target_x, target_y, x, y, &r_x, flag, &xorg, &yorg, &a_start, &a_end)) {
                cmd_buf.add_byte(CMD_ARC_ABS);
                cmd_buf.add_word(xorg);
                cmd_buf.add_word(yorg);
                cmd_buf.add_word(r_x); 
                cmd_buf.add_word(a_start);
                cmd_buf.add_word(a_end);
                cmd_buf.add_word(x);
                cmd_buf.add_word(y);
              } else {
                cmd_buf.add_byte(CMD_LINE_ABS);
                cmd_buf.add_word(x);
                cmd_buf.add_word(y);
              }
            } else error_flag = true;
          } else error_flag = true;
        } else error_flag = true;
      } else error_flag = true;
      break;

    case CMD_ARC_REL:                               // 10 - arc relative
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {                        // x
        if (parse_number(buf, &y, &pnt)) {                      // y
          if (parse_number(buf, &r_x, &pnt) && (r_x > 0)) {     // r
            if (parse_number(buf, &flag, &pnt)) {
              if (calc_arc_details(target_x, target_y, target_x + x, target_y + y, &r_x, flag, &xorg, &yorg, &a_start, &a_end)) {
                cmd_buf.add_byte(CMD_ARC_ABS);
                cmd_buf.add_word(xorg);
                cmd_buf.add_word(yorg);
                cmd_buf.add_word(r_x); 
                cmd_buf.add_word(a_start);
                cmd_buf.add_word(a_end);
                cmd_buf.add_word(target_x + x);
                cmd_buf.add_word(target_y + y);
              } else {
                cmd_buf.add_byte(CMD_LINE_ABS);
                cmd_buf.add_word(target_x + x);
                cmd_buf.add_word(target_y + y);
              }
            } else error_flag = true;
          } else error_flag = true;
        } else error_flag = true;
      } else error_flag = true;
      break;

    case CMD_CLOSE_POLY:                          // 7 - close polygon
    case CMD_CLOSE_POLY_lc:
      cmd_buf.add_byte(CMD_CLOSE_POLY);
      break;

    case CMD_PEN_DOWN:                            // 8 - pen down
    case CMD_PEN_DOWN_lc:
      cmd_buf.add_byte(CMD_PEN_DOWN);
      break;
      
    case CMD_PEN_UP:                              // 9 - pen up
    case CMD_PEN_UP_lc:
      cmd_buf.add_byte(CMD_PEN_UP);
      break;

    case CMD_CIRCLE:                              // 10 - draw a circle
    case CMD_CIRCLE_lc:
      a_start = 0;
      a_end = 360;
      ++pnt;
      if (parse_number(buf, &r_x, &pnt) && (r_x > 0)) {
        if ((buf[pnt] != ';') && (buf[pnt] != '\n') && (buf[pnt] != '\0')) {       // more to come?
          if ((buf[pnt] == ',') && parse_number(buf, &a_start, &pnt)) {
            if ((buf[pnt] == ',') && parse_number(buf, &a_end, &pnt)) {
              ;
            } else error_flag = true;
          } else error_flag = true;
        }
      } else error_flag = true;
      if (!error_flag) {
        cmd_buf.add_byte(CMD_CIRCLE);
        cmd_buf.add_word(r_x);
        cmd_buf.add_word(r_x);
        cmd_buf.add_word(a_start);
        cmd_buf.add_word(a_end);
      }
      break;

    case CMD_ELLIPSE:                               // 12 - draw an ellipse
    case CMD_ELLIPSE_lc:
      a_start = 0;
      a_end = 360;
      ++pnt;
      if (parse_number(buf, &r_x, &pnt) && (r_x > 0)) {
        if (parse_number(buf, &r_y, &pnt) && (r_y > 0)) {
          if ((buf[pnt] != ';') && (buf[pnt] != '\n') && (buf[pnt] != '\0')) {       // more to come?
            if ((buf[pnt] == ',') && parse_number(buf, &a_start, &pnt)) {
              if ((buf[pnt] == ',') && parse_number(buf, &a_end, &pnt)) {
                ;
              } else error_flag = true;
            } else error_flag = true;
          }
        } else error_flag = true;
      } else error_flag = true;
      if (!error_flag) {
        cmd_buf.add_byte(CMD_CIRCLE);
        cmd_buf.add_word(r_x);
        cmd_buf.add_word(r_y);
        cmd_buf.add_word(a_start);
        cmd_buf.add_word(a_end);
      }
      break;

    case CMD_TEXT:                                    // 14 - plot left aligned text
      ++pnt;
      cmd_buf.add_byte(CMD_TEXT);
      while ((buf[pnt] >= ' ') && (pnt < INPUT_BUFFER_SIZE)) {
        cmd_buf.add_byte(buf[pnt]);
        ++pnt;
      }
      cmd_buf.add_byte(0);
      break;

    case CMD_TEXT_RIGHT:                              // 15 - plot right adjusted text
      ++pnt;
      cmd_buf.add_byte(CMD_TEXT_RIGHT);
      while ((buf[pnt] >= ' ') && (pnt < INPUT_BUFFER_SIZE)) {
        cmd_buf.add_byte(buf[pnt]);
        ++pnt;
      }
      cmd_buf.add_byte(0);
      break;

    case CMD_TEXT_CENTERED:                           // 16 - plot centered text
    case CMD_TEXT_CENTERED_lc:
      ++pnt;
      cmd_buf.add_byte(CMD_TEXT_CENTERED);
      while ((buf[pnt] >= ' ') && (pnt < INPUT_BUFFER_SIZE)) {
        cmd_buf.add_byte(buf[pnt]);
        ++pnt;
      }
      cmd_buf.add_byte(0);
      break;

    case CMD_TEXT_ORIENTATION:                        // 17 - set text orientation 
    case CMD_TEXT_ORIENTATION_lc:
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {
        cmd_buf.add_byte(CMD_TEXT_ORIENTATION);
        cmd_buf.add_byte(x & 0xff);
      } else error_flag = true;
      break;
      
    case CMD_TEXT_SIZE:                               // 18 - set text size
    case CMD_TEXT_SIZE_lc:
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {
        cmd_buf.add_byte(CMD_TEXT_SIZE);
        cmd_buf.add_word(x);
      } else error_flag = true;
      break;

    case CMD_SET_SPEED:                             // 19 - set speed while pen is down
    case CMD_SET_SPEED_lc:
      ++pnt;
      if (parse_number(buf, &x, &pnt)) {
        if ((x >= TIMER_DELAY_BASELINE_FAST) && (x <= 1000)) { 
          cmd_buf.add_byte(CMD_SET_SPEED);
          cmd_buf.add_word(x);
        } else error_flag = true;
      } else error_flag = true;
      break;
      
    case CMD_PAUSE:                                   // 20 - toggle "pause mode"
    case CMD_PAUSE_lc:
      cmd_buf.add_byte(CMD_PAUSE);
      break;

    case CMD_HOME:                                    // 21 - move home
    case CMD_HOME_lc:
      cmd_buf.add_byte(CMD_PEN_UP);
      cmd_buf.add_byte(CMD_MOVE_ABS);
      cmd_buf.add_word(0);
      cmd_buf.add_word(0);
      break;

    case CMD_SET_LINE_NO:                             // 22 - set line number
    case CMD_SET_LINE_NO_lc:
      x = 0;
      ++pnt;
      while (buf[pnt] == ' ') ++pnt;
      if ((buf[pnt] != ';') && (buf[pnt] != '\n') && (buf[pnt] != '\0')) {       // more to come?
        if (!parse_number(buf, &x, &pnt) || (x < 0)) 
          error_flag = true;   
      }
      if (!error_flag) {
        cmd_buf.add_byte(CMD_SET_LINE_NO);
        cmd_buf.add_word(x);
      }
      break;
     
    case CMD_GET_COORDS:                              // 23 - get current position
    case CMD_GET_COORDS_lc:
      itoa(target_x, feedback, 10);
      len = strlen(feedback);
      feedback[len] = ',';
      itoa(target_y, feedback + len + 1, 10);
      feedback_flag = true;
      break;

    case CMD_SHOW_INFO:                                 // 24 - show system status
    case CMD_SHOW_INFO_lc:
      generate_status(feedback);
      feedback_flag = true;
      break;

    case CMD_GET_FREE_MEM:                                // 25 - get free buffer space
    case CMD_GET_FREE_MEM_lc:
      itoa(CMD_BUFFER_SIZE - cmd_buf.get_buffer_cnt(), feedback, 10);
      feedback_flag = true;
      break;

    case CMD_SET_NETWORK:                                 // 26 - set network connection
    case CMD_SET_NETWORK_lc:
      if (ser_input) {
        ws.select();
        disp.show_ip();
      } else {
        strcpy(feedback, "?");
        feedback_flag = true;
      }
      break;

    case CMD_STOP:                                        // 27 - stop and clear buffer
    case CMD_STOP_lc:
      cmd_buf.clear_buffer();
      break;
         
    default:
      error_flag = true;  
  }
  if (error_flag) {
    strcpy(feedback, "?");
    feedback_flag = true;
  }
  return feedback_flag;
}

/* ------------------------------------------------------------------------------------------
 *  Scans multiple input lines
 *  Parameters:
 *    char buf[] -> string with one or more lines
 *    char feedback[] -> resulting data. In case of error it contains a '?'.
 *    return value: true for "feedback is available", false for "no feedback given"
 */
bool parse_lines(char buf[], char feedback[], bool ser_input) {
  int pnt, end_pnt = 0;
  char cmd_line[256], feedback_fragment[256], util_buf[16];
  bool input_end = false, feedback_flag = false;
  extern int line_cnt;

  if (debug) Serial.println("Function parse_lines");
  feedback[0] = '\0';

  // search for line  break or string end
  while (!input_end) {
    pnt = 0;
    // skip blanks or tabs
    while ((buf[end_pnt] == ' ') || (buf[end_pnt] == '\t')) ++end_pnt;
    if ((buf[end_pnt] == CMD_TEXT) || (buf[end_pnt] == CMD_TEXT_CENTERED) || 
        (buf[end_pnt] == CMD_TEXT_CENTERED_lc) || (buf[end_pnt] == CMD_TEXT_RIGHT)) {
      while ((buf[end_pnt] != '\n') && (buf[end_pnt] != '\0')) {    // scan for line break
        cmd_line[pnt] = buf[end_pnt];
        ++pnt;
        ++end_pnt;
      };
    } else {                                                        // otherweise: scan for line break and semicolon
      while ((buf[end_pnt] != ';') && (buf[end_pnt] != '\n') && (buf[end_pnt] != '\0')) {
        cmd_line[pnt] = buf[end_pnt];
        ++pnt;
        ++end_pnt;
      };
    }
    if ((buf[end_pnt] == '\0') || ((buf[end_pnt] == '\n') && (buf[end_pnt+1] != '\0'))) ++line_cnt;  // increase line counter
    cmd_line[pnt] = '\0';
    if (strlen(cmd_line) > 0) {
      feedback_flag |= parse_input(cmd_line, feedback_fragment, ser_input);
      if (feedback_flag) {
          gen_line_cnt(util_buf);
          strcat(feedback, util_buf);
          strcat(feedback, feedback_fragment);
      }
    }
    if (buf[end_pnt] == '\0') input_end = true;
    else ++end_pnt;
  }
  return feedback_flag;
}  


// check_input ---------------------------------------------------------------------------------
void check_input(void) {
  extern Socket ws;
  char input_buf[INPUT_BUFFER_SIZE], feedback_buf[1024];
  int input_buf_pnt = 0;
  bool ser_input = false, net_input = false;

  if (ws.available() > 0) {
     ws.read_chararray(input_buf, INPUT_BUFFER_SIZE);
     if (debug) Serial.print("input_buf:");
     if (debug) Serial.println(input_buf);
     net_input = true;
  } else if (Serial.available() > 0) {
     get_serial_str(input_buf, INPUT_BUFFER_SIZE);
     ser_input = true;
  }

  // process input
  if (net_input || ser_input) {
    parse_lines(input_buf, feedback_buf, ser_input);
    if (strlen(feedback_buf) == 0)
      strcpy(feedback_buf, prompt);
  }

  // send output
  if (net_input) {
    ws.send(feedback_buf);
    net_input = false;
  } else if (ser_input) {
    Serial.print(feedback_buf);
    ser_input = false;
  }
}

/* itoaf ---------------------------------------------------------------------------------------
* Converts an integer to a string including basic formatting 
* positions -> total number of digits to be reserved 
* dec_point -> number of positions from the right for a dcimal point. 0 -> no decimal point
*/
void itoaf(int32_t value, char s[], uint8_t digits, const uint8_t dec_point) {
  uint8_t count, blank_flag = 0, neg_flag = 0;
  const uint32_t start_denom[] = {0, 10, 100, 1000, 10000, 100000, 1000000, 10000000};
  uint32_t denominator;
  int pnt = 0;

  if (value < 0) {
    neg_flag = 1;
    value = -value;
  }
  
  if (digits > 8) digits = 8;
  if (digits < 1) digits = 1;
  denominator = start_denom[digits - 1];
  if (value == 0) {
    s[pnt] = ' ';
    ++pnt;
  }
  while (digits > 0) {
    count = value / denominator;
    value -= count * denominator;
    if (digits == dec_point + 1) blank_flag = 1;
    if (digits == dec_point) {
      s[pnt] = ('.');
      ++pnt;
    }
    if ((count == 0) && (blank_flag == 0)) {
      s[pnt] = (' ');
      ++pnt;
    } else {
      if (blank_flag == 0) {
        if (neg_flag) s[pnt] = '-';
        else s[pnt] = ' ';
        ++pnt;
      }
      s[pnt] = ('0' + count);
      ++pnt;
      blank_flag = 1;
    };
    --digits;
    denominator /= 10;
  };
  s[pnt] = 0;
}

/* get_serial_str -------------------------------------------------------------------------*/
void get_serial_str(char input_buf[], int buf_size) {
  int pnt = 0;
  
  if (Serial.available() > 0) {
    while ((Serial.available() > 0) && (pnt < buf_size - 1)) {
      input_buf[pnt] = Serial.read();
      pnt += 1; 
    }
    while (input_buf[pnt] == '\n')
      pnt -= 1;                           // remove trailing linebreak 
    input_buf[pnt] = '\0';    
  }
}

/* buf_to_int -------------------------------------------------------------------------*/
bool buf_to_int(char buf[], int *n) {
  int factor = 1, pnt = strlen(buf);
  *n = 0;

  while (pnt > 0) {
    --pnt;
    if ((buf[pnt] >= '0') && (buf[pnt] <= '9')) {
      *n += factor * int(buf[pnt] - '0');
      factor *= 10;
    } else {
      return false;
    }
  }
  return true;
}

/* generate_line_cnt ------------------------------------------------------------------*/
void gen_line_cnt(char buf[]) {
  char util_buf[16];
  extern int line_cnt;
  
  buf[0] = '\n';
  buf[1] = '[';
  itoa(line_cnt, util_buf, 10);
  strcpy(buf+2, util_buf);
  strcat(buf, "]: ");
}

/* generate_status ----------------------------------------------------------------------*/
void generate_status(char buf[]) {
  extern Socket ws;
  extern Plotter pl;
  char util_buf[16];
  String local_ip;
  
  strcpy(buf, "XY Plotter\n");
  strcat(buf, "Network: ");
  ws.get_local_ip(util_buf);
  strcat(buf, util_buf);
  strcat(buf, "\n");
  strcat(buf, "Plotting area: ");
  itoa(MAX_X, util_buf, 10); strcat(buf, util_buf); strcat(buf, ", ");
  itoa(MAX_Y, util_buf, 10); strcat(buf, util_buf); strcat(buf, "\n");
  strcat(buf, "Char size: "); itoa(pl.get_char_size(), util_buf, 10);
  strcat(buf, util_buf); strcat(buf, "\n");
  strcat(buf, "Plot speed (delay time): "); itoa(pl.get_speed(), util_buf, 10);
  strcat(buf, util_buf); strcat(buf, "\n");
  strcat(buf, VERSION_NO); strcat(buf, "\n");
  strcat(buf, VERSION_DATE); 
}

/* calc_arc_Details ---------------------------------------------------------------------
Calculates center, start- and end-angle and stepwidth for the construction of an arc
Returns: true in case of success, false if the calculation does not give a result
*/
bool calc_arc_details(int x_start, int y_start, int x_end, int y_end, int *r, int flag, int *xorg, int *yorg, int *a_start, int *a_end) {
  int delta_x = x_end - x_start, delta_y = y_end - y_start;
  float c = sqrt(delta_x * delta_x + delta_y * delta_y);
  float x, y, y_square, ex1, ey1, ex2, ey2, q1x, q1y, q2x, q2y;
  
  if (flag != 0) flag = 1;

  // calc origin
  if (*r < c / 2) {
    if (debug) Serial.print("r corrected");
    *r = int(c / 2);
  };
  if (c < 1) {
    if (debug) Serial.println("No solution");
    return false;      // no solution, both points are on the same spot
  }
  x = c*c / (2*c);
  y_square = *r * *r - x*x;
  if (y_square < 0) {
    if (debug) Serial.println("No solution");
    return false;      // no solution, radius too small
  }
  y = sqrt(y_square);
  ex1 = delta_x / c;
  ex2 = delta_y / c;
  ey1 = -ex2;
  ey2 = ex1;
  q1x = x_start + x * ex1;
  q1y = y_start + x * ex2;
  if (abs(y) < 0.1) {
    *xorg = int(q1x);
    *yorg = int(q1y);
  } else {
    q2x = q1x - y * ey1;
    q2y = q1y - y * ey2;
    q1x += y * ey1;
    q1y += y * ey2;
    if (flag > 0) {
      if (q2y > q1y) {
        *xorg = int(q1x); *yorg = int(q1y);
      } else {
        *xorg = int(q2x); *yorg = int(q2y);
      }    
    } else {
      if (q2y > q1y) {
        *xorg = int(q2x); *yorg = int(q2y);
      } else {
        *xorg = int(q1x); *yorg = int(q1y);
      }     
    }
  }
  // calc angles
  if (x_end > x_start) flag = 1 - flag;
  *a_start = calc_angle(*xorg, *yorg, x_start, y_start);
  *a_end = calc_angle(*xorg, *yorg, x_end, y_end);
  if (flag > 0) {
    while (*a_start < *a_end) *a_start += 360;
  } else {
    while (*a_end < *a_start) *a_end += 360;
  }
  if (debug) {
    Serial.println("Calc Arc Details");
    Serial.print("x1: "), Serial.print(x_start);
    Serial.print("y1: "), Serial.println(y_start);
    Serial.print("x2: "), Serial.print(x_end);
    Serial.print("y2: "), Serial.println(y_end);
    Serial.print("r: ");  Serial.println(*r);
    Serial.print("qx: "); Serial.print(*xorg);
    Serial.print("   qy: "); Serial.println(*yorg);
    Serial.print("a_start: "); Serial.println(*a_start);
    Serial.print("a_end: "); Serial.println(*a_end);
  };
  return true;
}

/* calc_angle ---------------------------------------------------------------------------
Calculates the angle of a line based on two coordinates
Returns: angle
*/
int calc_angle(int x1, int y1, int x2, int y2) {
  int x_delta = x2 - x1;
  float m;
  const float pi = 3.14159265358979;

  if (x_delta == 0) {
    if (y2 > y1) return 0;
    else return 180;
  }
  m = (y2 - y1) / (float) x_delta;
  if (x2 > x1) return int((pi/2 - atan(m)) * 180 / pi);
  else return int((pi*3/2 - atan(m)) * 180 / pi);
}

/* plot_rectangle -----------------------------------------------------------------------
Generates the plot commands for a rectangle 
*/
bool plot_rectangle(int x, int y, int width, int height, int r) {
  extern CmdBuffer cmd_buf;
  int xorg, yorg, a_start, a_end;

  cmd_buf.add_byte(CMD_PEN_UP);
  if (r < 5) {
    cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x); cmd_buf.add_word(y);
    cmd_buf.add_byte(CMD_PEN_DOWN);
    cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x); cmd_buf.add_word(y + height);
    cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x + width); cmd_buf.add_word(y + height);
    cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x + width); cmd_buf.add_word(y);
    cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x); cmd_buf.add_word(y);
    cmd_buf.add_byte(CMD_PEN_UP);
  } else {
    if ((r > height / 2) || (r > width / 2)) {
      return false;                                                                                                   // radius too big
    } else {
      int x_new, y_new;
      cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x); cmd_buf.add_word(y + r);
      cmd_buf.add_byte(CMD_PEN_DOWN);
      
      cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x); cmd_buf.add_word(y + height - r);                    // left moving up
      x_new = x + r; y_new = y + height; 
      if (calc_arc_details(x, y + height - r, x_new, y_new, &r, 1, &xorg, &yorg, &a_start, &a_end)) {           // upper left corner
        cmd_buf.add_byte(CMD_ARC_ABS); cmd_buf.add_word(xorg);cmd_buf.add_word(yorg); cmd_buf.add_word(r); 
        cmd_buf.add_word(a_start); cmd_buf.add_word(a_end); cmd_buf.add_word(x_new); cmd_buf.add_word(y_new);
      }
      cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x + width - r); cmd_buf.add_word(y + height);            // top moving right
      x_new = x + width; y_new = y + height - r; 
      if (calc_arc_details(x + width - r, y + height, x_new, y_new, &r, 1, &xorg, &yorg, &a_start, &a_end)) {   // upper right corner
        cmd_buf.add_byte(CMD_ARC_ABS); cmd_buf.add_word(xorg);cmd_buf.add_word(yorg); cmd_buf.add_word(r); 
        cmd_buf.add_word(a_start); cmd_buf.add_word(a_end); cmd_buf.add_word(x_new); cmd_buf.add_word(y_new);
      }
      cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x + width); cmd_buf.add_word(y + r);                     // right moving down
      x_new = x + width - r; y_new = y; 
      if (calc_arc_details(x + width, y + r, x_new, y_new, &r, 0, &xorg, &yorg, &a_start, &a_end)) {            // lower right corner
        cmd_buf.add_byte(CMD_ARC_ABS); cmd_buf.add_word(xorg);cmd_buf.add_word(yorg); cmd_buf.add_word(r); 
        cmd_buf.add_word(a_start); cmd_buf.add_word(a_end); cmd_buf.add_word(x_new); cmd_buf.add_word(y_new);
      }
      cmd_buf.add_byte(CMD_MOVE_ABS); cmd_buf.add_word(x + r); cmd_buf.add_word(y);                             // bottom moving left
      x_new = x; y_new = y + r; 
      if (calc_arc_details(x + r, y, x_new, y_new, &r, 0, &xorg, &yorg, &a_start, &a_end)) {                    // lower left corner
        cmd_buf.add_byte(CMD_ARC_ABS); cmd_buf.add_word(xorg);cmd_buf.add_word(yorg); cmd_buf.add_word(r); 
        cmd_buf.add_word(a_start); cmd_buf.add_word(a_end); cmd_buf.add_word(x_new); cmd_buf.add_word(y_new);
      }
      cmd_buf.add_byte(CMD_PEN_UP);
    }
  }    
  return true;
}      
