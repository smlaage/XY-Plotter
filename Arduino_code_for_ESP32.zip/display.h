#ifndef __DISPLAY__
#define __DISPLAY__

#include <Arduino.h>
#include <LiquidCrystal_I2C.h>

#define I2C_ADDRESS 0x27

class LCD_Display {
  
	private:
		char system_state_msg[7][16] = {"Reset Y", "Reset X", "Ready", "Standby", "Plotting", "Stopped", "Manual"};

	public:
		void start_display(void); 
    void show_counter(int cnt);
		void show_system_state(int system_state);
		void show_ip(void);
    void show_socket_status(bool socket_status);
		void clear_ip(void);
		void show_buf_cnt(int buf_cnt);
		void show_pen(bool pen_status);
		void show_pos(int x , int y);
};

#endif
