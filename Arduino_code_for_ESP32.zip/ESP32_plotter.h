#ifndef __ESP32_PLOTTER__
#define __ESP32_PLOTTER__

#define VERSION_NO "Version 0.91"
#define VERSION_DATE "SLW - 2021-01-08"

// commands -------------------------------------------------------------------------------------------------
#define CMD_MOVE_ABS 'M'          // 1
#define CMD_MOVE_REL 'm'          // 2
#define CMD_LINE_ABS 'L'          // 3
#define CMD_LINE_REL 'l'          // 4
#define CMD_RECTANGLE_ABS 'R'     // 5, 7
#define CMD_RECTANGLE_REL 'r'     // 6, 8
#define CMD_ARC_ABS 'A'           // 9
#define CMD_ARC_REL 'a'           // 10
#define CMD_CLOSE_POLY 'Z'        // 11
#define CMD_CLOSE_POLY_lc 'z'
#define CMD_PEN_UP 'U'            // 12
#define CMD_PEN_UP_lc 'u'   
#define CMD_PEN_DOWN 'D'          // 13
#define CMD_PEN_DOWN_lc 'd'
#define CMD_CIRCLE 'C'            // 14, 15
#define CMD_CIRCLE_lc 'c'
#define CMD_ELLIPSE 'E'           // 16, 17
#define CMD_ELLIPSE_lc 'e'      

#define CMD_TEXT 'T'              // 20
#define CMD_TEXT_RIGHT 't'        // 21
#define CMD_TEXT_CENTERED 'J'     // 22
#define CMD_TEXT_CENTERED_lc 'j'
#define CMD_TEXT_ORIENTATION 'O'  // 23
#define CMD_TEXT_ORIENTATION_lc 'o'
#define CMD_TEXT_SIZE 'S'         // 24
#define CMD_TEXT_SIZE_lc 's'
#define CMD_TEXT_ATTRIBUTE 'K'    // 25
#define CMD_TEXT_ATTRIBUTE_lc 'k' 

#define CMD_SET_SPEED 'V'         // 30
#define CMD_SET_SPEED_lc 'v'
#define CMD_PAUSE 'P'             // 31
#define CMD_PAUSE_lc 'p'          
#define CMD_HOME 'H'              // 32
#define CMD_HOME_lc 'h'
#define CMD_SET_LINE_NO 'B'       // 33
#define CMD_SET_LINE_NO_lc 'b' 
#define CMD_GET_COORDS 'G'        // 34
#define CMD_GET_COORDS_lc 'g'
#define CMD_SHOW_INFO 'I'         // 35
#define CMD_SHOW_INFO_lc 'i'
#define CMD_GET_FREE_MEM 'F'      // 36
#define CMD_GET_FREE_MEM_lc 'f'
#define CMD_SET_NETWORK 'N'       // 37
#define CMD_SET_NETWORK_lc 'n'
#define CMD_STOP 'X'              // 38
#define CMD_STOP_lc 'x'

// servo pen positions
#define PEN_UP          97  // servo position for pen up
#define PEN_DOWN       128  // servo position for pen down
#define PEN_UP_TIME    100  // delay time to wait for the pen to be lifted [msec]
#define PEN_DOWN_TIME  200  // delay time to wait for the pen to be settled on the paper [msec]
#define PEN_UP_CNT_MAX   5  // time of inactivity until the pen ist lifted

// pin assignments ------------------------------------------------------------------------------------------
#define PIN_SERVO     13
#define PIN_XA_STEP   25
#define PIN_XA_DIR    26
#define PIN_XB_STEP   33
#define PIN_XB_DIR    16
#define PIN_X_ENABLE  17
#define PIN_Y_STEP    12
#define PIN_Y_DIR     14
#define PIN_Y_ENABLE  27

#define PIN_Y_BT      34
#define PIN_XA_BT     32
#define PIN_XB_BT     35

#define PIN_MS1       18
#define PIN_MS2       19

#define PIN_BT_0       2
#define PIN_BT_1       4
#define PIN_BT_2      15

// drive speed including ramp
#define RESET_SPEED      1
#define TIMER_DELAY_BASELINE_SLOW 750     // start of ramp
#define TIMER_DELAY_BASELINE_FAST 475     // fast speed while pen is up
#define TIMER_DELAY_RAMP_1    60    // speed: 244
#define TIMER_DELAY_STEP_1     4
#define TIMER_DELAY_RAMP_2   130    // speed: 112
#define TIMER_DELAY_STEP_2     2
#define TIMER_DELAY_RAMP_3   170    // speed:  72
#define TIMER_DELAY_STEP_3     1

// drive range
#define MAX_X        12320
#define MAX_Y         9900
#define RESET_OFFSET    20        // distance to mechanical stop after reset
#define PLOT_LIMIT  -99999

#define SYS_STATE_READY     2
#define SYS_STATE_STANDBY   3
#define SYS_STATE_PLOTTING  4
#define SYS_STATE_STOPPED   5
#define SYS_STATE_MANUAL    6

#define INPUT_BUFFER_SIZE 1024

#endif
